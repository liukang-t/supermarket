<!-- 商品介绍卡片 -->
<template>
  <div data-flex="" class="course-detail-card div p-20">
    <el-row :gutter="60" class="w-100">
      <el-col :md="14" :sm="14">
        <img
          v-if="data.pic"
          :src="data.pic"
          alt=""
          class="w-100"
          :style="{ objectFit: 'cover', maxHeight: '300px' }"
        />
        <img
          v-else
          src="/image/banner.png"
          alt="默认图片"
          class="w-100"
          :style="{ objectFit: 'cover', maxHeight: '300px' }"
        />
      </el-col>
      <el-col :md="10" :sm="10" class="p-5">
        <h1 class="f-22 p-b-10 b-b">[{{ data.name }}]</h1>
        <div>
          <p class="m-t-18 m-b-5 f-18">商品介绍</p>
          <div class="o-8" :style="{ lineHeight: '1.7' }">
            {{ data.title || "暂无简介" }}
          </div>
        </div>
        <div>
          <p class="m-t-18 m-b-5 f-18">价格: {{ data.price || "暂无" }}</p>
        </div>
        <div class="a-l m-t-20" data-flex="cross:center" v-if='!isIn'>
          <div>
            <button class="btn-item active" @click="getSelecteds()">立即购买</button>
            <button class="btn-item" @click="addCar()">
              加入购物车
            </button>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import {isInMyCourse} from "@/request/mycourse";
import {addShopCar} from "@/request/cart";
import {mapState} from 'vuex'
export default {
  props: {
    data: {
      type: Object,
    },
    courseId:{
      type:String,
    },
    leix: {
    type: String,
    required: true
    }
  },
  computed: {
    ...mapState({
      userInfo: (state) => state.userinfo,
    }),
  },
  data() {
    return {
      isIn :false
    }
  },
  methods: {
    addCar() {
      if (!sessionStorage.getItem('token')) {
        this.$message({
          message: "请先登陆",
          type: "warning",
          duration: 800,
        });
        setTimeout(() => {
            this.$router.push("/login");
        }, 1000);
      }else{
        addShopCar({
        id:this.courseId,
        leix:this.leix,
        type:1
      }).then((res) => {
        if (res.data.data !=null) {
          this.$message({
            message: res.data.data.data[0]["name"]+"成功加入购物车",
            type: "success",
            duration: 800,
          });
        } else {
          this.$message({
            message: "已经加入购物车了",
            type: "error",
            duration: 800,
          });
        }
      });
      }
      
    },
    
    getSelecteds() {
      this.addCar();
      const confirmation = confirm("购买成功，即将前往购物车");
    if (confirmation) {   
        setTimeout(() => {
            this.$router.push("/cart");
        }, 3000);
    } else {
        // 用户取消跳转，不执行任何操作
    }
    },
    init(){
      isInMyCourse({
        courseId: this.courseId,
        id: this.userInfo.id,
        leix:this.leix,
        type:1}).then(res=>{
              this.isIn = res.message
        })
    }
  },
  mounted() {
  console.log(this.leix);
    this.init()
  },
};
</script>
<style scoped src="../../assets/css/base.scss" lang="scss"></style>
<style lang="scss" scoped>
.course-detail-card {
  ::v-deep .el-icon-star-on {
    font-size: 32px;
    cursor: pointer;
  }
  ::v-deep .el-icon-star-off {
    font-size: 28px;
  }
}
.btn-item {
  width: 120px;
  height: 40px;
  /*margin: 0 20px 0 0;*/
  padding: 0px;
  border: 0px;
  outline: none;
  color: #f11d1d;
  border-radius: 23px;
  cursor: pointer;
}
.active {
  background: #f11d1d !important;
  color: #ffffff;
  margin-right: 10px;
}
</style>