import request from './request.js'

//获取商品分类
export const getCourseAllType = () => request.get('/api/courseType')
//首页展示商品
export const queryNew = () => request.get('/api/queryNew')
//根据id商品获取商品信息
export const getCouresDetailInfo = (params) => request.post('/api/courseInfoById', params)

//根据id商品获取商品所有章节
export const getCouresAllSection = (params) => request.post('/api/couresAllSection', params)

//根据商品id获取，章节列表。根据章节id获取改章节信息
export const playCourse = (params) => request.post('/sectionList', params)
    //获取弹幕
export const getDanmu = (query) => request({
        url: '/danmu',
        method: 'get',
        params: {
            id: query
        }
    })
//商品中心获取商品分类
export const courseSearch = (params) => request.post('/api/courseSearch', params)