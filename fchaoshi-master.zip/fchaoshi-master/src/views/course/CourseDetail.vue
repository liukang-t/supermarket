<!-- 商品详情页面 -->
<template>
  <div>
    <Header></Header>
    <course-detail-card
      :data="cardInfo"
      :courseId="id"
      :leix="leix"
    ></course-detail-card>

    <!-- 商品目录 -->

    <!-- 底部 -->
    <Footer></Footer>
  </div>
</template>

<script>
import Header from '@/components/index/Header'
import Footer from '@/components/index/Footer'
import CourseDetailCard from '@/components/course/CourseDetailCard'

import { getCouresDetailInfo } from '../../request/course'

export default {
  components:{
    Header,
    Footer,
    CourseDetailCard,
  },
  data() {
    return {
      // 商品卡片内容
      cardInfo: {},
      firstDetail: {},
      leix: null, // 添加leix属性，默认值为null
    }
  },
  methods: {
    getCardInfo() {
      const leix = this.$route.query.leix
      const id = this.$route.params.id
      getCouresDetailInfo({ id, leix }).then(res => {
        console.log(res.data.data)
        this.cardInfo = res.data.data[0]
      })
    },
    getFirstCatalog(val) {
      if (val.length > 0) {
        this.firstDetail = val[0]
      }
    },
  },
  computed: {
    id() {
      console.log(this.$route)
      return this.$route.params.id
    },
  },
  created() {
    this.leix = this.$route.query.leix // 在created生命周期中给leix属性赋值
    this.getCardInfo()
  }
}
</script><style scoped src="../../assets/css/base.scss" lang="scss"></style>
<style lang="scss" scoped>
@media only screen {
  .course-detail-card {
    margin: 10% 15%;
  }
  .course-detail-catalog {
    margin: 3% 15%;
  }
}
</style>
