<template>
  <div class="lore">
    <img src="image/login/bg.png" alt="" class="bg" />
    <div class="content">
      <!--背景图片-->
      <div class="img">
        <img src="image/login/bg.svg" alt="" />
      </div>
      <!--登录、注册-->
      <div class="login-register">
        <transition-group
          name="animate__animated animate__bounce"
          appear
          enter-active-class="animate__zoomInUp"
          leave-active-class="animate__zoomOutDown"
        >
          <!--登录-->
          <div class="login" key="lo" v-show="istype">
            <el-form
              ref="loginForm"
              :model="loginForm"
              :rules="rules"
              label-width="1.2rem"
              size="small"
            >
              <img src="image/login/avatar.svg" alt="" class="avatar" />
              <div class="header-title">
                <h3 :class="{ fcolor: istype }" @click="changeTable">登录</h3>
                <h3 :class="{ fcolor: !istype }" @click="changeTable">注册</h3>
              </div>
              <el-form-item prop="teacherName">
                <el-input
                  v-model="loginForm.teacherName"
                  placeholder="用户名"
                  prefix-icon="iconfont icon-youxiang"
                ></el-input>
              </el-form-item>
              <el-form-item prop="password">
                <el-input
                  v-model="loginForm.password"
                  placeholder="密码"
                  prefix-icon="el-icon-unlock"
                  show-password
                  type="password"
                  auto-complete="new-password"
                ></el-input>
              </el-form-item>
              <el-button round @click="submitForm1('loginForm')"
                >登录</el-button
              >
            </el-form>
          </div>
          <!--注册-->
          <div class="register" key="re" v-show="!istype">
            <el-form
              ref="registerForm"
              :model="registerForm"
              :rules="rules"
              label-width="1.2rem"
              size="small"
            >
              <img src="image/login/avatar.svg" alt="" class="avatar" />
              <div class="header-title">
                <h3 :class="{ fcolor: istype }" @click="changeTable">登录</h3>
                <h3 :class="{ fcolor: !istype }" @click="changeTable">注册</h3>
              </div>
              <el-form-item prop="teacherName">
                <el-input
                  v-model="registerForm.teacherName"
                  placeholder="用户名"
                  prefix-icon="el-icon-user-solid"
                ></el-input>
              </el-form-item>
              <el-form-item prop="password">
                <el-input
                  v-model="registerForm.password"
                  placeholder="密码"
                  prefix-icon="el-icon-unlock"
                  show-password
                  type="password"
                  auto-complete="new-password"
                ></el-input>
              </el-form-item>
              <el-form-item prop="checkpwd">
                <el-input
                  v-model="registerForm.checkpwd"
                  placeholder="确认密码"
                  prefix-icon="el-icon-unlock"
                  show-password
                  type="password"
                ></el-input>
              </el-form-item>
              <div class="xyi">
                注册表示您已经同意我们的<a @click="ystk">隐私条款</a>
              </div>
              <el-button round @click="submitForm2('registerForm')"
                >注册</el-button
              >
            </el-form>
          </div>
        </transition-group>
      </div>
    </div>
  </div>
</template>
<script>

import {register, login } from "@/request/user";
export default {
  name: "LoOrRe",
  metaInfo: {
      title: '登录注册', // set a title
    },
  data() {
    //自定义密码规则
    var validatePass = (rule, value, callback) => {
      //正则表达式  密码
      var passwordreg = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[^]{8,16}$/;

      if (value === "") {
        callback(new Error("请输入密码"));
      } else {
        if (!passwordreg.test(value)) {
          callback(
            new Error("至少8-16个字符，至少要包含大写字母，小写字母和数字")
          );
        } else {
          this.$refs.registerForm.validateField("checkPass");
        }
        callback();
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请再次输入密码"));
      } else if (value !== this.registerForm.password) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    };
    return {
      //注册表单信息
      registerForm: {
        teacherName: "",
        password: "",
        checkpwd: "",
      },
      //登录表单信息
      loginForm: {
        teacherName: "",
        password: "",
      },
      //验证规则   注册表单和登录表单共用
      rules: {
        teacherName: [
          { required: true, message: "请输入用户名", trigger: "blur" },
          { min: 4, max: 8, message: "长度在 4 到 8 个字符", trigger: "blur" },
        ],
        password: [{ validator: validatePass, trigger: "blur" }],
        checkpwd: [{ validator: validatePass2, trigger: "blur" }],
      },
      //登录还是注册
      istype: true,
    };
  },
  mounted() {
  },
  methods: {
    //登录表单提交信息
    submitForm1(formname) {

      //提交表单信息
      this.$refs[formname].validate((valid) => {
        if (valid) {
          login(this.loginForm).then((res) => {
            console.log(res.data.success);
            if (res.data.success == false) {
              // alert(res.data.msg)
              this.open(res.data.msg);
            } else {
              //将token储存在sessionStorage
              sessionStorage.setItem("token", res.data.data.token);
              const userDto = JSON.stringify(res.data.data.userDto);
              sessionStorage.setItem("userDto",userDto);
              //跳转页面
              this.$router.push('/');
            }
          });
        } else {
          console.log("提交失败");
          return false;
        }
      });
    },
    //注册表单提交信息
    submitForm2(formname) {
      //提交表单信息
      this.$refs[formname].validate((valid) => {
        if (valid) {
          register(this.registerForm).then((res) => {
            this.open(res.data.msg);
          });
        } else {
          return false;
        }
      });
    },
    //切换表单
    changeTable() {
      this.istype = !this.istype;
    },
    //重置密码页面
    resetPwd() {
      this.$router.push({
        name: "Resetpwd",
      });
    },
    //提示
    open(content) {
      this.$message.alert(content, "提示", {
        confirmButtonText: "确定",
      });
    },
    //跳转隐私条款页面
    ystk() {
      this.$router.push({
        name: "Ystk",
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.lore {
  .bg {
    position: fixed;
    left: 0;
    bottom: 0;
    height: 100%;
    width: 100%;
    z-index: -1;
  }
  .content {
    width: 100vw;
    height: 100vh;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 18rem;
    padding: 0 2rem;
    .img {
      display: flex;
      justify-content: flex-end;
      align-items: center;

      img {
        width: 500px;
        border-radius: 100%;
        overflow: hidden;
        border: 10px solid rgb(230, 250, 120);
      }
    }
    /*登录注册 */
    .login-register {
      display: flex;
      align-items: center;
      text-align: center;
      overflow: hidden;
      .register,
      .login {
        .el-form {
          width: 400px;
          .avatar {
            width: 100px;
            border-radius: 100%;
            overflow: hidden;
            border: 5px solid rgb(230, 250, 120);
          }
          .header-title {
            display: flex;
            justify-content: space-around;
            h3 {
              font-size: 2.9rem;
              text-transform: uppercase;
              margin: 15px 0;
              color: #999;
              &:hover {
                cursor: pointer;
              }
            }
          }

          .pw {
            width: 90%;
            margin: 0 auto;
            margin-bottom: 20px;
            display: flex;
            justify-content: right;
            text-align: center;
            .el-button {
              width: 40%;
              background: rgb(56, 179, 200);
              color: white;
              text-align: center;
            }
            a {
              cursor: pointer;
              color: rgb(43, 145, 204);
              font-size: 14px;
              padding-top: 16px;
            }
          }
          .el-button {
            width: 80%;
            background: rgb(56, 179, 200);
            color: white;
          }
          /* 邮箱验证码 */
          .eyzm {
            .el-button,
            .el-input {
              width: 30%;
            }
            .el-input {
              width: 70%;
            }
          }
          /* 协议 */
          .xyi {
            font-size: 10px;
            text-align: center;
            margin: 15px 0;
            color: #8a8888;
            a {
              color: rgb(12, 186, 255);
              cursor: pointer;
            }
          }
        }
      }
    }
  }
  #tyzm {
    display: flex;
    flex-wrap: nowrap;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
    span {
      width: 300px;
      height: 40px;
    }
    input {
      flex: 1;
      height: 32px;
      line-height: 32px;
      outline: none;
      border-radius: 4px;
      border: 1px solid #dcdfe6;
      &:focus {
        border: 1px solid #2d73f5;
      }
    }
  }
  /*媒体查询*/
  @media screen and (max-width: 1080px) {
    .content {
      grid-gap: 9rem;
    }
  }
  @media screen and (max-width: 1024px) {
    .el-form {
      width: 290px;
    }
    .el-formform h3 {
      font-size: 2.4rem;
      margin: 8px 0;
    }
    .img img {
      width: 360px;
    }
  }
  @media screen and (max-width: 768px) {
    .bg {
      display: none;
    }
    .content .img {
      display: none;
    }
    .content {
      grid-template-columns: 1fr;
    }
    .content .login-register {
      justify-content: center;
    }
  }
  /*登录，注册字体颜色 */
  .fcolor {
    color: rgb(119, 203, 252) !important;
    border-bottom: 2px solid rgb(119, 203, 252) !important;
  }
}
</style>