package com.example.demo.beans;

import lombok.Data;

@Data
public class CommonResult implements Comparable {

    private static final Integer SUCCESS_CODE = 200;

    private static final Integer FAIL_CODE = 500;

    private Integer code;

    private String  msg;

    private Object data;


    public static CommonResult success(String msg, Object data){
        CommonResult commonResult = new CommonResult();
        commonResult.code = CommonResult.SUCCESS_CODE;
        commonResult.msg = msg;
        commonResult.data = data;
        return commonResult;
    }

    public static CommonResult success(String msg){
        CommonResult commonResult = new CommonResult();
        //限于本类使用
        commonResult.code = CommonResult.SUCCESS_CODE;
        commonResult.msg = msg;
        return commonResult;
    }

    public static CommonResult error(String msg){
        CommonResult commonResult = new CommonResult();
        commonResult.code = CommonResult.FAIL_CODE;
        commonResult.msg = msg;
        return commonResult;
    }

    public boolean isSuccess(){
        return this.code == CommonResult.SUCCESS_CODE;
    }

    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
