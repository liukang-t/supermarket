package com.example.demo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class LoginConfig implements WebMvcConfigurer {
    /**
     * 注册拦截器
     * @param registry
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        //添加登录拦截器
//        registry.addInterceptor(new LoginInterceptor())
//                .addPathPatterns("/**")
//                //指定了需要拦截的请求路径模式。这里使用的是"/**"，表示对所有请求路径进行拦截
//                .excludePathPatterns(
//                        //登录
//                        "/api/login",
//                        //注册
//                        "/api/register",
//                        "/api/getUserByToken"
//                );
        //指定了不需要被拦截的请求路径模式，即放行的接口,对于这些路径，
        // 即使满足被拦截的条件，也不会被拦截器处理，而是直接放行。
    }
}
