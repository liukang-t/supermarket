package com.example.demo.config;

import cn.hutool.json.JSONObject;
import com.example.demo.utils.SessionUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * 接口拦截器
 */
public class LoginInterceptor implements HandlerInterceptor {

    /**
     *  请求接口之前（权限判断）
     * @param request 请求
     * @param response 响应
     * @param handler
     * @return true-放行 false-拦截
     * @throws Exception
     */
    //快捷键 alt + insert
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {


        //判断是否登录
        String token = SessionUtil.getTokenFromRequest(request);
        if (StringUtils.isBlank(token)){
            returnFalseMsg(response,"请先登录然后再访问",request);
            return false;
        }
        //验证缓存中的用户是否存在
        HttpSession session = request.getSession();
        Object userInfo = session.getAttribute(token);
        if (userInfo == null){
            returnFalseMsg(response,"请先登录然后再访问",request);
            return false;
        }
        return true;
    }

    /**
     *  请求之后，返回之前
     * @param request
     * @param response
     * @param handler
     * @param modelAndView
     * @throws Exception
     */
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    /**
     * 视图渲染后
     * @param request
     * @param response
     * @param handler
     * @param ex
     * @throws Exception
     */
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }


    //验证token失败，返回失败信息
    private void returnFalseMsg(ServletResponse response, String msg, HttpServletRequest request) throws IOException {
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        //强制转换`ServletResponse`为`HttpServletResponse`对象，以便设置响应相关的信息
        httpServletResponse.setStatus(200);
        //设置响应状态码为200
        httpServletResponse.setContentType("application/json;charset=utf-8");
        //设置响应数据类型为json 编码格式utf-8格式
        PrintWriter writer = httpServletResponse.getWriter();
        //获取输出流`PrintWriter`对象，用于向客户端输出数据
         JSONObject jsonObject=new JSONObject();
        //创建一个`JSONObject`对象用于构建JSON格式的返回数据。
        jsonObject.put("code", 401);
        //设置响应数据中的code值为401，表示"Unauthorized"，即未经授权。它是HTTP协议中的一种状态码
        jsonObject.put("msg", org.springframework.util.StringUtils.isEmpty(msg) ? "登录已失效，请重新登录！" : msg);
        //设置响应数据中的msg值为"登录已失效，请重新登录！"，如果msg参数不为空，则使用msg参数的值
        jsonObject.put("uri", request.getRequestURI());
        //设置响应数据中的uri值为当前请求的URI
        jsonObject.put("url", request.getRequestURL());
        //设置响应数据中的url值为当前请求的URL
        writer.println(jsonObject);
        //向客户端输出JSON格式的数据
        writer.flush();
        //刷新输出流
        writer.close();
        //关闭输出流
    }
}
