package com.example.demo.controller;


import cn.hutool.core.util.ObjectUtil;
import com.example.demo.beans.CommonResult;

import com.example.demo.service.CartService;
import com.example.demo.vo.CartVo;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author mp
 * @since 2023-12-31
 */
@RestController
@RequestMapping("/cart")
public class CartController {
    @Resource
    CartService cartService;

    @PostMapping("/getShopCar")
    private CommonResult getShopCar(HttpServletRequest request, @RequestBody CartVo cartVo){
        if (ObjectUtil.isNull(cartVo)){
            return CommonResult.error("参数不能为空");
        }
        return cartService.getShopCar(request,cartVo);
    }
    @PostMapping("/addShopCar")
    private CommonResult addShopCar(HttpServletRequest request, @RequestBody CartVo cartVo){
        if (ObjectUtil.isNull(cartVo)){
            return CommonResult.error("参数不能为空");
        }
        return cartService.addShopCar(request,cartVo);
    }
    @PostMapping("/deleteShopCar")
    private CommonResult deleteShopCar(HttpServletRequest request, @RequestBody CartVo cartVo){
        if (ObjectUtil.isNull(cartVo)){
            return CommonResult.error("参数不能为空");
        }
        return cartService.deleteShopCar(request,cartVo);
    }

}

