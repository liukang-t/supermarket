package com.example.demo.controller;

import com.example.demo.beans.CommonResult;
import com.example.demo.utils.UploadFileUtil;
import com.sun.deploy.net.URLEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

@RestController
@RequestMapping("/file")
public class FileController {
    @PostMapping("/upload")
    public CommonResult uploadFileAjax(HttpServletRequest request) throws IOException {
        MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
        MultipartFile file = multiRequest.getFile("file");
        String url = UploadFileUtil.localSave(file,"8084");
        return CommonResult.success("上传成功",url);
    }
    @GetMapping("/getFile")
    public void getFile(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //读取路径下面的文件
        String filePath = request.getParameter("filePath");
        String name = null;
        //获取最后一个？号
        int index = filePath.lastIndexOf("?");
        if (index > 0 ){
            //获取最后一个=号
            int indexOf = filePath.lastIndexOf("=");
            name = filePath.substring(indexOf+1);
            filePath = filePath.substring(0,index);
        }
        if (name == null){
            name = Long.toString(System.currentTimeMillis());
        }
        //处理结束后执行
        File file = new File(filePath);
        String suffix = filePath.substring(filePath.lastIndexOf("."));
        System.out.println("准备返回文件，文件路径为==>"+filePath);
        System.out.println("文件名==>"+name);
        response.setHeader("Content-disposition", "attachment; filename=" + URLEncoder.encode(name,"utf-8")  +suffix);
        //读取指定路径下面的文件
        InputStream in = new FileInputStream(file);
        OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
        //创建存放文件内容的数组
        byte[] buff =new byte[1024];
        //所读取的内 容使用n来接收
        Integer n = null;
        //当没有读取完时,继续读取,循环
        while((n=in.read(buff))!=-1){
            //将字节数组的数据全部写入到输出流中
            outputStream.write(buff,0,n);
        }
        //强制将缓存区的数据进行输出
        outputStream.flush();
        //关流
        outputStream.close();  
        in.close();
    }
}
