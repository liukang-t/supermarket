package com.example.demo.controller;


import cn.hutool.core.util.ObjectUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.service.PayService;
import com.example.demo.vo.PayVo;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author mp
 * @since 2024-01-01
 */
@RestController
@RequestMapping("/pay")
public class PayController {
    @Resource
    PayService payService;

    @PostMapping("/checkout")
    private CommonResult checkout(HttpServletRequest request, @RequestBody PayVo payVo){
        if (ObjectUtil.isNull(payVo)){
            return CommonResult.error("参数不能为空");
        }
        return payService.checkout(request,payVo);
    }
    @PostMapping("/alipay")
    private CommonResult alipay(HttpServletRequest request, @RequestBody PayVo payVo){
        if (ObjectUtil.isNull(payVo)){
            return CommonResult.error("参数不能为空");
        }
        return payService.alipay(request,payVo);
    }
}

