package com.example.demo.controller;


import cn.hutool.core.util.ObjectUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.service.QueryService;
import com.example.demo.vo.QueryVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author mp
 * @since 2023-12-31
 */
@RestController

@RequestMapping("/api")
public class QueryController {
    @Resource
    QueryService queryService;

    @PostMapping("/courseSearch")
    private CommonResult getResourceList(HttpServletRequest request,@RequestBody QueryVo queryVo){
        if (ObjectUtil.isNull(queryVo)){
            return CommonResult.error("参数不能为空");
        }
        return queryService.getResourceList(request,queryVo);
    }
    @PostMapping("/courseInfoById")
    private CommonResult getCouresDetailInfo(HttpServletRequest request,@RequestBody QueryVo queryVo){
        if (ObjectUtil.isNull(queryVo)){
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(queryVo.getId())){
            return CommonResult.error("id不能为空");
        }
        return queryService.getCouresDetailInfo(request,queryVo);
    }
}

