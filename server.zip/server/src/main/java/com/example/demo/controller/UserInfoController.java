package com.example.demo.controller;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.dto.UserDto;
import com.example.demo.service.UserInfoService;
import com.example.demo.utils.SessionUtil;
import com.example.demo.vo.UserInfoVo;
import org.apache.tomcat.jni.User;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author mp
 * @since 2023-10-30
 */
@RestController
@RequestMapping("/api")
public class UserInfoController {
@Resource
private UserInfoService userInfoService;


    @PostMapping("/register")
    public Comparable register(HttpServletRequest request, @RequestBody UserInfoVo userInfoVo){
    //返回结果
    Comparable result=null;
    //校检参数
    if(ObjectUtil.isNull(userInfoVo)){
        return CommonResult.error("参数不能为空");
    }
    if(StrUtil.isBlank(userInfoVo.getTeacherName())){
        return CommonResult.error("账号不能为空");
    }
    if(StrUtil.isBlank(userInfoVo.getPassword())){
        return CommonResult.error("密码不能为空");
    }
        try {
            result =userInfoService.register(request,userInfoVo);
        } catch (Exception e) {
            return CommonResult.error("注册失败");
        }
        return result;
    }
    @PostMapping("/login")
    public CommonResult login(HttpServletRequest request, @RequestBody UserInfoVo userInfoVo){
        if(ObjectUtil.isNull(userInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if(StrUtil.isBlank(userInfoVo.getTeacherName())){
            return CommonResult.error("账号不能为空");
        }
        if(StrUtil.isBlank(userInfoVo.getPassword())){
            return CommonResult.error("密码不能为空");
        }
        return  userInfoService.login(request,userInfoVo);
    }
    @PostMapping("/changePassword")
    public CommonResult changePassword(HttpServletRequest request,@RequestBody UserInfoVo userInfoVo){

        if(ObjectUtil.isNull(userInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if(StrUtil.isBlank(userInfoVo.getOldPassword())){
            return CommonResult.error("旧密码不能为空");
        }
        if(StrUtil.isBlank(userInfoVo.getNewPassword())){
            return CommonResult.error("新密码不能为空");
        }
        return  userInfoService.changePassword(request,userInfoVo);
    }
    @PostMapping("/updateAvatar")
    public  CommonResult updateAvatar(HttpServletRequest request, @RequestBody UserInfoVo userInfoVo){
        if (ObjectUtil.isNull(userInfoVo)){
            return  CommonResult.error("参数为空");
        }
        if (StrUtil.isBlank(userInfoVo.getAvatar())){
            return CommonResult.error("头像参数为空");
        }
        return userInfoService.updateAvatar(request,userInfoVo);
    }
    @GetMapping("/queryList")
    public  CommonResult queryList(HttpServletRequest request, UserInfoVo userInfoVo){
        if (ObjectUtil.isNull(userInfoVo)){
            return  CommonResult.error("参数为空");
        }
        return userInfoService.queryList(request,userInfoVo);
    }
    @GetMapping("/queryNew")
    public  CommonResult queryNew(HttpServletRequest request, UserInfoVo userInfoVo){
        if (ObjectUtil.isNull(userInfoVo)){
            return  CommonResult.error("参数为空");
        }
        return userInfoService.queryNew(request,userInfoVo);
    }
    @PostMapping("/liveSearch")
    public  CommonResult liveSearch(HttpServletRequest request,@RequestBody UserInfoVo userInfoVo){
        if (ObjectUtil.isNull(userInfoVo)){
            return  CommonResult.error("参数为空");
        }
        return userInfoService.liveSearch(request,userInfoVo);
    }
}


