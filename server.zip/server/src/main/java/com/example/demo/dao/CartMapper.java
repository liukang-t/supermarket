package com.example.demo.dao;

import com.example.demo.po.Cart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2023-12-31
 */
public interface CartMapper extends BaseMapper<Cart> {

}
