package com.example.demo.dao;

import com.example.demo.dto.StudentDailyReportDto;
import com.example.demo.po.DailyReport;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.vo.DailyReportVo;

import java.util.List;

/**
 * <p>
 * 学生日报表 Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2023-12-03
 */
public interface DailyReportMapper extends BaseMapper<DailyReport> {

    List<StudentDailyReportDto> selectStudentDailyReportList(DailyReportVo dailyReportVo);

    Integer countStudentDailyReport(DailyReportVo dailyReportVo);
}
