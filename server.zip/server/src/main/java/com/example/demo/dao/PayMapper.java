package com.example.demo.dao;

import com.example.demo.po.Pay;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2024-01-01
 */
public interface PayMapper extends BaseMapper<Pay> {

}
