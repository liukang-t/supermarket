package com.example.demo.dao;

import com.example.demo.dto.TaskGradeDto;
import com.example.demo.po.TaskGrade;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.vo.TaskGradeVo;

import java.util.List;

/**
 * <p>
 * 任务评分表 Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2023-12-04
 */
public interface TaskGradeMapper extends BaseMapper<TaskGrade> {


    List<TaskGradeDto> getTaskScoreList(TaskGradeVo taskGradeVo);

    Integer countTaskScore(TaskGradeVo taskGradeVo);
}
