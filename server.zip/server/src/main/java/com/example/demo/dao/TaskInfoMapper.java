package com.example.demo.dao;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.demo.po.TaskGrade;
import com.example.demo.po.TaskInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 任务表 Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2023-12-03
 */
public interface TaskInfoMapper extends BaseMapper<TaskInfo> {


    List<TaskGrade> selectList(LambdaQueryWrapper<TaskGrade> queryWrapper);
}
