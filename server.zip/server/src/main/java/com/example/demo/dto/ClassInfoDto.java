package com.example.demo.dto;

import com.example.demo.po.ClassInfo;
import lombok.Data;

@Data
public class ClassInfoDto extends ClassInfo {

    /**
     * 班级总人数
     */
    private Integer totalCount;

    /**
     * 女生数量
     */
    private Integer nanCount;

    /**
     * 男生数量
     */
    private Integer nvCount;
}