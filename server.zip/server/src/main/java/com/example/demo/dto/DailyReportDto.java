package com.example.demo.dto;

import com.example.demo.po.DailyReport;
import lombok.Data;

@Data
/**
 * <p>
 * 学生日报表 Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2023-12-03
 */
public class DailyReportDto extends DailyReport {

    /**
     *
     */
    private String relationStudentName;

}
