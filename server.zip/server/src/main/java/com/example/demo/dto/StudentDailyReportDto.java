package com.example.demo.dto;

import lombok.Data;

import java.util.Date;

@Data
public class StudentDailyReportDto {
    /**
     * 学生id
     */
    private Integer studentId;
    /**
     * 学生姓名
     */
    private String studentName;
    /**
     * 学校
     */
    private String studentNumber;
    /**
     * 院系
     */
    private String schoolName;
    /**
     * 班级名称
     */
    private String departmentName;
    /**
     * 最后提交时间
     */
    private String className;

    private Date lastCommitTime;

    private Integer commitCount;
}
