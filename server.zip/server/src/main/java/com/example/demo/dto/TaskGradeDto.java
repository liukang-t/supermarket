package com.example.demo.dto;

import lombok.Data;

@Data
public class TaskGradeDto {

    //* 学生id
    private Integer studentId;

//*学生姓名

    private String studentName;

//学生学号

    private String studentNumber;


    private String score;
}
