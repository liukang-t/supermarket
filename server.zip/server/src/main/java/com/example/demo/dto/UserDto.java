package com.example.demo.dto;

import com.example.demo.po.UserInfo;
import lombok.Data;

@Data
public class UserDto extends UserInfo {

    /**
     * 教师信息
     */
    private UserInfo userInfo;


}
