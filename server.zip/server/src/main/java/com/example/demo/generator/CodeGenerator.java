package com.example.demo.generator;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import com.baomidou.mybatisplus.generator.config.GlobalConfig;
import com.baomidou.mybatisplus.generator.config.PackageConfig;
import com.baomidou.mybatisplus.generator.config.StrategyConfig;
import com.baomidou.mybatisplus.generator.config.po.TableFill;
import com.baomidou.mybatisplus.generator.config.rules.DateType;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;

import java.util.ArrayList;


public class CodeGenerator {
    public static void main(String[] args) {
        AutoGenerator mpg = new AutoGenerator();
        //1、全局配置
        GlobalConfig gc = new GlobalConfig();
        //输出目录
        String path = System.getProperty("user.dir");
        gc.setOutputDir(path+"/src/main/java");
        gc.setAuthor("mp");
        gc.setOpen(false);
        //是否覆盖原文件
        gc.setFileOverride(false);
        // 去I前缀
        gc.setServiceName("%sService");
        gc.setIdType(IdType.AUTO);
        gc.setDateType(DateType.ONLY_DATE);
        gc.setSwagger2(false);
        gc.setServiceName("%sService");
        //放入全局配置
        mpg.setGlobalConfig(gc);

        //2、设置数据源
        DataSourceConfig dc = new DataSourceConfig();
        //本地
        dc.setUrl("jdbc:mysql://localhost:3306/shixunyun?useUnicode=true&serverTimezone=Asia/Shanghai&characterEncoding=utf-8&useSSL=false&allowMultiQueries=true&rewriteBatchedStatements=true");
        dc.setUsername("root");
        dc.setPassword("root");
        dc.setDriverName("com.mysql.cj.jdbc.Driver");
        dc.setDbType(DbType.MYSQL);
        mpg.setDataSource(dc);

        PackageConfig pc = new PackageConfig();
//      pc.setModuleName("model");
        pc.setParent("com.example.demo");
        pc.setEntity("po");
        pc.setMapper("dao");

        pc.setService("service");
        pc.setController("controller");
        pc.setServiceImpl("service.impl");
        pc.setXml("mapper");
        mpg.setPackageInfo(pc);

        StrategyConfig sc = new StrategyConfig();
        //设置映射的表名,多张表用逗号“，”隔开
        sc.setInclude("user_info","query","cart","pay");
        //表名转驼峰
        sc.setNaming(NamingStrategy.underline_to_camel);
        //字段名转驼峰
        sc.setColumnNaming(NamingStrategy.underline_to_camel);
        //lombok注释
        sc.setEntityLombokModel(true);
        //生成@RestController注解
        sc.setRestControllerStyle(true);
        //生成字段注解
        sc.setEntityTableFieldAnnotationEnable(true);
        //自动填充
        TableFill createTime = new TableFill("create_time", FieldFill.INSERT);
        TableFill updateTime = new TableFill("update_time", FieldFill.UPDATE);

        ArrayList<TableFill> tableFiles = new ArrayList<>();
        tableFiles.add(createTime);
        tableFiles.add(updateTime);
        sc.setTableFillList(tableFiles);
        //乐观锁
//        sc.setVersionFieldName("version");
        sc.setRestControllerStyle(true);

        mpg.setStrategy(sc);

        mpg.execute();
    }
}
