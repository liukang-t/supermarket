package com.example.demo.po;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 资源表
 * </p>
 *
 * @author mp
 * @since 2023-11-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ResourceInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 编号
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 资源类型 1-链接 2-文件
     */
    @TableField("leix")
    private String leix;

    /**
     * 资源名称
     */
    @TableField("name")
    private String name;

    /**
     * 资源链接
     */
    @TableField("pic")
    private String pic;

    /**
     * 资源描述
     */
    @TableField("buy_n")
    private String buy_n;

    /**
     * 关联教师id
     */
    @TableField("price")
    private Integer price;


}
