package com.example.demo.po;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 任务评分表
 * </p>
 *
 * @author mp
 * @since 2023-12-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TaskGrade implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 编号
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;

    /**
     * 创建时间
     */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 更新人
     */
    @TableField("update_by")
    private Integer updateBy;

    /**
     * 更新时间
     */
    @TableField(value = "update_time", fill = FieldFill.UPDATE)
    private Date updateTime;

    /**
     * 删除 0-未删除 1-已删除
     */
    @TableField("deleted")
    private Integer deleted;

    /**
     * 分数
     */
    @TableField("score")
    private String score;

    /**
     * 关联任务id
     */
    @TableField("relation_task_id")
    private Integer relationTaskId;

    /**
     * 关联学生id
     */
    @TableField("relation_student_id")
    private Integer relationStudentId;

    /**
     * 关联教师id
     */
    @TableField("relation_teacher_id")
    private Integer relationTeacherId;


}
