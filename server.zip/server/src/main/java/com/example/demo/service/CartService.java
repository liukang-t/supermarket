package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.Cart;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.CartVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author mp
 * @since 2023-12-31
 */
public interface CartService extends IService<Cart> {

    CommonResult getShopCar(HttpServletRequest request, CartVo cartVo);

    CommonResult addShopCar(HttpServletRequest request, CartVo cartVo);

    CommonResult deleteShopCar(HttpServletRequest request, CartVo cartVo);
}
