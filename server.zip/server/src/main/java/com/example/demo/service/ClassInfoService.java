package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.ClassInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.ClassInfovo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 班级表 服务类
 * </p>
 *
 * @author mp
 * @since 2023-10-30
 */
public interface ClassInfoService extends IService<ClassInfo> {

    CommonResult addCalsss(HttpServletRequest request, ClassInfovo classInfovo);

    CommonResult getClassList(HttpServletRequest request, ClassInfovo classInfovo);

    CommonResult modifuClas(HttpServletRequest request, ClassInfovo classInfovo);

    CommonResult deletedClass(HttpServletRequest request, ClassInfovo classInfovo);

    CommonResult getClassInfo(HttpServletRequest request);
}
