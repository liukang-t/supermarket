package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.DailyReport;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.DailyReportVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 学生日报表 服务类
 * </p>
 *
 * @author mp
 * @since 2023-12-03
 */
public interface DailyReportService extends IService<DailyReport> {

    CommonResult addDailyReport(HttpServletRequest request, DailyReportVo dailyReportVo);

    CommonResult getStudentDailyList(HttpServletRequest request, DailyReportVo dailyReportVo);

    CommonResult getDailyReportList(HttpServletRequest request, DailyReportVo dailyReportVo);

    CommonResult commentOnDailyReport(HttpServletRequest request, DailyReportVo dailyReportVo);
}
