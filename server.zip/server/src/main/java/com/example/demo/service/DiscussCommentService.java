package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.DiscussComment;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.DiscussCommentVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 评论表 服务类
 * </p>
 *
 * @author mp
 * @since 2023-12-10
 */
public interface DiscussCommentService extends IService<DiscussComment> {

    CommonResult addDiscussComment(HttpServletRequest request, DiscussCommentVo discussCommentVo);
}
