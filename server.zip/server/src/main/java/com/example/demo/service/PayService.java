package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.Pay;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.PayVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author mp
 * @since 2024-01-01
 */
public interface PayService extends IService<Pay> {

    CommonResult checkout(HttpServletRequest request, PayVo payVo);

    CommonResult alipay(HttpServletRequest request, PayVo payVo);
}
