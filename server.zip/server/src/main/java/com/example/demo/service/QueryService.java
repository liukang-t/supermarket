package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.Query;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.QueryVo;
import com.example.demo.vo.ResourceInfoVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author mp
 * @since 2023-12-31
 */
public interface QueryService extends IService<Query> {

    CommonResult getResourceList(HttpServletRequest request, QueryVo queryVo);

    CommonResult getCouresDetailInfo(HttpServletRequest request, QueryVo queryVo);
}
