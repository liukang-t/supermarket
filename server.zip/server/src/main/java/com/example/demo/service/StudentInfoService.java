package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.StudentInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.StudentInfoVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 学生 服务类
 * </p>
 *
 * @author mp
 * @since 2023-10-30
 */
public interface StudentInfoService extends IService<StudentInfo> {

    CommonResult deleteStudent(HttpServletRequest request, StudentInfoVo studentInfoVo) throws Exception;

    CommonResult addStudent(HttpServletRequest request, StudentInfoVo studentInfoVo) throws Exception;

    CommonResult getStudentList(HttpServletRequest request, StudentInfoVo studentInfoVo);

    CommonResult modifyStudent(HttpServletRequest request, StudentInfoVo studentInfoVo) throws Exception;
}

