package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.TaskGrade;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.TaskGradeVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 任务评分表 服务类
 * </p>
 *
 * @author mp
 * @since 2023-12-04
 */
public interface TaskGradeService extends IService<TaskGrade> {

    CommonResult getTaskScoreList(HttpServletRequest request, TaskGradeVo taskGradeVo);

    CommonResult modifyTaskScore(HttpServletRequest request, TaskGradeVo taskGradeVo);
}
