package com.example.demo.service;

import javax.servlet.http.HttpServletRequest;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.UserInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.UserInfoVo;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author mp
 * @since 2023-10-30
 */
public interface UserInfoService extends IService<UserInfo> {

    CommonResult register(HttpServletRequest request, UserInfoVo userInfoVo) throws Exception;

    CommonResult login(HttpServletRequest request, UserInfoVo userInfoVo);

    CommonResult changePassword(HttpServletRequest request, UserInfoVo userInfoVo);

    CommonResult updateAvatar(HttpServletRequest request, UserInfoVo userInfoVo);


    CommonResult queryList(HttpServletRequest request, UserInfoVo userInfoVo);

    CommonResult queryNew(HttpServletRequest request, UserInfoVo userInfoVo);

    CommonResult courseType(HttpServletRequest request, UserInfoVo userInfoVo);

    CommonResult liveSearch(HttpServletRequest request, UserInfoVo userInfoVo);

}
