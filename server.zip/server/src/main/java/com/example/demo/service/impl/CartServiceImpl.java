package com.example.demo.service.impl;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.Cart;
import com.example.demo.dao.CartMapper;
import com.example.demo.po.Query;
import com.example.demo.service.CartService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.vo.CartVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author mp
 * @since 2023-12-31
 */
@Service
public class CartServiceImpl extends ServiceImpl<CartMapper, Cart> implements CartService {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public CommonResult getShopCar(HttpServletRequest request, CartVo cartVo) {
        try {
            // 执行查询，获取表数据信息
            String sql = "SELECT * FROM cart";
            List<Cart> resourceList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Cart.class));
            // 返回结果给前端
            HashMap<String, Object> map = new HashMap<>();
            map.put("data", resourceList);
            map.put("status", resourceList.size());
            return CommonResult.success("查询成功", map);
        } catch (Exception e) {
            e.printStackTrace();
            return CommonResult.error("查询失败");
        }
    }

    @Override
    public CommonResult addShopCar(HttpServletRequest request, CartVo cartVo) {
        System.out.println(cartVo.leix);
        String spId = cartVo.getLeix() + "_" + cartVo.getId();

// 查询是否存在相同的sp_id
        String selectSql = "SELECT COUNT(*) FROM cart WHERE sp_id = ?";
        int count = jdbcTemplate.queryForObject(selectSql, Integer.class, spId);

        if (count != 0) {
            return CommonResult.error("插入失败");
        }else{
        if (cartVo.leix ==2){
            try {
                // 执行查询，获取表数据信息
                String sql = "SELECT * FROM query2 WHERE id = " + cartVo.getId();
                List<Query> resourceList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Query.class));
                for (Query query : resourceList) {
                        String insertSql = "INSERT INTO cart(checked,sp_id, pic, type, name, title, price) VALUES (?,?, ?, ?, ?, ?, ?)";
                        jdbcTemplate.update(
                                insertSql,
                                1,
                                cartVo.leix + "_" + cartVo.getId(),
                                query.getPic(),
                                1,
                                query.getName(),
                                query.getTitle(),
                                query.getPrice()
                        );
                }
                String sql2 = "SELECT * FROM cart WHERE sp_id = "+"'"+cartVo.leix+"_"+cartVo.getId()+"'";
                List<Cart> resourceList1 = jdbcTemplate.query(sql2, new BeanPropertyRowMapper<>(Cart.class));
                // 返回结果给前端
                HashMap<String, Object> map = new HashMap<>();
                map.put("data", resourceList1);
                map.put("status", resourceList.size());
                return CommonResult.success("插入成功", map);
            } catch (Exception e) {
                e.printStackTrace();
                return CommonResult.error("插入失败");
            }
        }else {
            try {
                // 执行查询，获取表数据信息
                String sql = "SELECT * FROM query WHERE id = " + cartVo.getId();
                List<Query> resourceList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Query.class));
                for (Query query : resourceList) {
                    String insertSql = "INSERT INTO cart(checked,sp_id, pic, type, name, title, price) VALUES (?,?, ?, ?, ?, ?, ?)";
                    jdbcTemplate.update(
                            insertSql,
                            1,
                            cartVo.leix + "_" + cartVo.getId(),
                            query.getPic(),
                            1,
                            query.getName(),
                            query.getTitle(),
                            query.getPrice()
                    );
                }
                String sql2 = "SELECT * FROM cart WHERE sp_id = " + "'" + cartVo.leix + "_" + cartVo.getId() + "'";
                List<Cart> resourceList1 = jdbcTemplate.query(sql2, new BeanPropertyRowMapper<>(Cart.class));
                // 返回结果给前端
                HashMap<String, Object> map = new HashMap<>();
                map.put("data", resourceList1);
                map.put("status", resourceList.size());
                return CommonResult.success("插入成功", map);
            } catch (Exception e) {
                e.printStackTrace();
                return CommonResult.error("插入失败");
            }
        }
        }
    }

    @Override
    public CommonResult deleteShopCar(HttpServletRequest request, CartVo cartVo) {
        try {
            String deleteSql = "DELETE FROM cart WHERE id = " + cartVo.getId();
            int rowsAffected = jdbcTemplate.update(deleteSql);

            if (rowsAffected > 0) {
                String sql = "SELECT * FROM cart";
                List<Cart> resourceList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Cart.class));
                HashMap<String, Object> map = new HashMap<>();
                map.put("data", resourceList);
                map.put("status", resourceList.size());
                return CommonResult.success("删除成功并查询成功", map);
            } else {
                return CommonResult.error("删除失败，未找到匹配的记录");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return CommonResult.error("删除失败");
        }
    }
}
