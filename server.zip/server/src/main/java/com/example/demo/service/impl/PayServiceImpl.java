package com.example.demo.service.impl;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.Pay;
import com.example.demo.dao.PayMapper;
import com.example.demo.service.PayService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.vo.CartVo;
import com.example.demo.vo.PayVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author mp
 * @since 2024-01-01
 */
@Service
public class PayServiceImpl extends ServiceImpl<PayMapper, Pay> implements PayService {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Override
    public CommonResult checkout(HttpServletRequest request, PayVo payVo) {
        try {
            // 获取 setArr 数组
            List<Map<String, Object>> setArr = payVo.getSetArr();
            String deleteSql = "TRUNCATE TABLE pay";
            jdbcTemplate.update(deleteSql);
            for (Map<String, Object> item : setArr) {
                // 获取 id 值
                int id = (int) item.get("id");
                // 1. 执行查询操作
                System.out.println(id);
                String querySql = "SELECT * FROM cart WHERE id = ?";
                List<Map<String, Object>> queryResult = jdbcTemplate.queryForList(querySql, id);
                System.out.println(queryResult);
                // 2. 将查询结果插入到目标表
                for (Map<String, Object> queryItem : queryResult) {
                    String searchSql = "SELECT id FROM pay WHERE id = ?";
                    List<Map<String, Object>> searchResult = jdbcTemplate.queryForList(searchSql, id);
                    if (searchResult.isEmpty()) {
                        String insertSql = "INSERT INTO pay (id, pic, type, name, title, price) VALUES (?, ?, ?, ?, ?, ?)";
                        jdbcTemplate.update(insertSql, id, queryItem.get("pic"), queryItem.get("type"),
                                queryItem.get("name"), queryItem.get("title"), queryItem.get("price"));
                        String deleteSql2 = "DELETE FROM cart WHERE id = ?";
                        jdbcTemplate.update(deleteSql2, id);
                    }
                }
            }
            System.out.println("数据插入成功");
            String sql = "SELECT * FROM pay";
            List<Map<String, Object>> queryResult = jdbcTemplate.queryForList(sql);
            // 返回插入成功的结果
            // 返回结果给前端
            HashMap<String, Object> map = new HashMap<>();
            map.put("data", queryResult);
            map.put("status", queryResult.size());

            return CommonResult.success("插入成功", map);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("插入数据时出错");

            // 返回插入失败的结果
            return  CommonResult.error("插入数据时出错");
        }
    }

    @Override
    public CommonResult alipay(HttpServletRequest request, PayVo payVo) {
        String deleteSql = "DELETE FROM pay";
        jdbcTemplate.update(deleteSql);
        // 返回结果
        String sql = "SELECT * FROM pay";
        List<Map<String, Object>> queryResult = jdbcTemplate.queryForList(sql);
        // 返回插入成功的结果
        // 返回结果给前端
        HashMap<String, Object> map = new HashMap<>();
        map.put("data", queryResult);
        return CommonResult.success("插入成功1", map);
    }
}