package com.example.demo.service.impl;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.Query;
import com.example.demo.dao.QueryMapper;
import com.example.demo.service.QueryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.vo.QueryVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author mp
 * @since 2023-12-31
 */
@Service
public class QueryServiceImpl extends ServiceImpl<QueryMapper, Query> implements QueryService {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public CommonResult getResourceList(HttpServletRequest request, QueryVo queryVo) {
        try {
            // 执行查询，获取表数据信息
            String sql = "SELECT * FROM query ";
            List<Query> resourceList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Query.class));
            // 返回结果给前端
            HashMap<String, Object> map = new HashMap<>();
            map.put("data", resourceList);
            map.put("status", resourceList.size());
            return CommonResult.success("查询成功", map);
        } catch (Exception e) {
            e.printStackTrace();
            return CommonResult.error("查询失败");
        }
    }

    @Override
    public CommonResult getCouresDetailInfo(HttpServletRequest request, QueryVo queryVo) {
        System.out.println(queryVo.leix);
        if (queryVo.leix == 2) {
            try {
                // 执行查询，获取表数据信息
                String sql = "SELECT * FROM query2 WHERE id =" + queryVo.getId() + ";";
                List<Query> resourceList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Query.class));
                // 返回结果给前端
                return CommonResult.success("查询成功", resourceList);
            } catch (Exception e) {
                e.printStackTrace();
                return CommonResult.error("查询失败");
            }
        } else {
        try {
            // 执行查询，获取表数据信息
            String sql = "SELECT * FROM query WHERE id =" + queryVo.getId() + ";";
            List<Query> resourceList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Query.class));
            // 返回结果给前端
            return CommonResult.success("查询成功", resourceList);
        } catch (Exception e) {
            e.printStackTrace();
            return CommonResult.error("查询失败");
        }
    }
    }
}
