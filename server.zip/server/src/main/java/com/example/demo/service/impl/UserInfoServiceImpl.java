package com.example.demo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.beans.CommonResult;
import com.example.demo.dao.StudentInfoMapper;
import com.example.demo.dao.TeacherInfoMapper;
import com.example.demo.dao.UserInfoMapper;
import com.example.demo.po.Query;
import com.example.demo.po.UserInfo;
import com.example.demo.service.UserInfoService;
import com.example.demo.utils.PasswordCryptoTool;
import com.example.demo.utils.SessionUtil;
import com.example.demo.vo.UserInfoVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo.dto.UserDto;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author mp
 * @since 2023-10-30
 */
@Service
public class UserInfoServiceImpl extends ServiceImpl<UserInfoMapper, UserInfo> implements UserInfoService {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Transactional(rollbackFor = Exception.class)
    @Override
    public CommonResult register(HttpServletRequest request, UserInfoVo userInfoVo) throws Exception {
        // 判断数据库是否有用户
        LambdaQueryWrapper<UserInfo> userInfoQueryWrapper = new LambdaQueryWrapper<UserInfo>()
                .eq(UserInfo::getAccountNumber, userInfoVo.getTeacherName());
        UserInfo userInfo = this.getOne(userInfoQueryWrapper);
        if (ObjectUtil.isNotNull(userInfo)) {
            // 如果用户已存在，返回注册失败
            return CommonResult.error("账号已存在，注册失败");
        }
        // 如果用户不存在，则新增用户
        UserInfo addUserInfo = new UserInfo();
        addUserInfo.setAccountNumber(userInfoVo.getAccountNum());
        addUserInfo.setAccountNumber(userInfoVo.getTeacherName()); // 设置用户名字段值
        // 加密密码
        String encryptPassword = PasswordCryptoTool.encryptPassword(userInfoVo.getPassword());
        addUserInfo.setPassword(encryptPassword);
        boolean save = this.save(addUserInfo);
        // 如果用户信息插入失败，返回注册失败
        if (!save) {
            return CommonResult.error("注册失败");
        }
        return CommonResult.success("注册成功");
    }
    @Override
    public CommonResult login(HttpServletRequest request, UserInfoVo userInfoVo) {
        //从数据库查询用户信息，用账号
        LambdaQueryWrapper<UserInfo> userInfoQueryWapper = new LambdaQueryWrapper<UserInfo>()
                .eq(UserInfo::getAccountNumber, userInfoVo.getTeacherName());
        UserInfo userInfo = this.getOne(userInfoQueryWapper);
        //查询用户信息是否为空
        if (ObjectUtil.isNull(userInfo)) {
            return CommonResult.error("账号不存在");
        }
        Boolean checkPassword = PasswordCryptoTool.checkPassword(userInfoVo.getPassword(), userInfo.getPassword());
        if (!checkPassword) {
            return CommonResult.error("账号或者密码错误");
        }
        //从请求中获取session
        HttpSession session = request.getSession();
        //从请求中获取token
        String token = UUID.randomUUID().toString();
        UserDto userDto = new UserDto();
        BeanUtil.copyProperties(userInfo, userDto);
        //用户信息放入session
        session.setAttribute(token, userDto);
        HashMap<String, Object> map = new HashMap<>();
        map.put("token", token);
        map.put("userDto", userDto);
        return CommonResult.success("登录成功", map);
    }
    @Override
    public CommonResult changePassword(HttpServletRequest request, UserInfoVo userInfoVo) {
        UserDto userDto=userInfoVo.userDto;
        //新建一个空的对象
        UserInfo userInfo = new UserInfo();
        //将用户信息复制到我们新建的对象里面
        BeanUtil.copyProperties(userDto,userInfo);
        //更新密码(加密新密码)
        String encryptedPassword = PasswordCryptoTool.encryptPassword(userInfoVo.getNewPassword());
        userInfo.setPassword(encryptedPassword);
        //更新数据库
        boolean update = this.updateById(userInfo);
        if(!update){
            return CommonResult.error("更新密码失败");
        }
        return CommonResult.success("修改密码成功");
    }

    @Override
    public CommonResult updateAvatar(HttpServletRequest request, UserInfoVo userInfoVo) {
        UserDto userInfoDto=userInfoVo.userDto;
        //创建更新对象，填充属性
        UserInfo userInfo = new UserInfo();
        userInfo.setUserAva(userInfoVo.getAvatar());
        System.out.println(userInfoVo.getAvatar());
        //更新数据库
        boolean update = this.updateById(userInfo);
        //更新缓存中的头像
        if (!update) {
            return CommonResult.error("更新头像失败");
        }
        userInfoDto.setUserAva(userInfoVo.getAvatar());
        return CommonResult.success("操作成功");
    }

    @Override
    public CommonResult queryList(HttpServletRequest request, UserInfoVo userInfoVo) {
        try {
            // 执行查询，获取表数据信息
            String sql = "SELECT * FROM query2 ";
            List<Query> resourceList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Query.class));
            // 返回结果给前端
            HashMap<String, Object> map = new HashMap<>();
            map.put("data", resourceList);
            map.put("status", resourceList.size());
            return CommonResult.success("查询成功", map);
        } catch (Exception e) {
            e.printStackTrace();
            return CommonResult.error("查询失败");
        }
    }
    @Override
    public CommonResult queryNew(HttpServletRequest request, UserInfoVo userInfoVo) {
        try {
            // 执行查询，获取表数据信息
            String sql = "SELECT * FROM query ";
            List<Query> resourceList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Query.class));
            // 返回结果给前端
            HashMap<String, Object> map = new HashMap<>();
            map.put("data", resourceList);
            map.put("status", resourceList.size());
            return CommonResult.success("查询成功", map);
        } catch (Exception e) {
            e.printStackTrace();
            return CommonResult.error("查询失败");
        }
    }

    @Override
    public CommonResult courseType(HttpServletRequest request, UserInfoVo userInfoVo) {
        try {
            // 执行查询，获取表数据信息
            String sql = "SELECT * FROM query ";
            List<Query> resourceList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Query.class));
            // 返回结果给前端
            HashMap<String, Object> map = new HashMap<>();
            map.put("data", resourceList);
            map.put("status", resourceList.size());
            return CommonResult.success("查询成功", map);
        } catch (Exception e) {
            e.printStackTrace();
            return CommonResult.error("查询失败");
        }
    }

    @Override
    public CommonResult liveSearch(HttpServletRequest request, UserInfoVo userInfoVo) {
        try {
            // 执行查询，获取表数据信息
            String sql = "SELECT * FROM query2 ";
            List<Query> resourceList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Query.class));
            // 返回结果给前端
            HashMap<String, Object> map = new HashMap<>();
            map.put("data", resourceList);
            map.put("status", resourceList.size());
            return CommonResult.success("查询成功", map);
        } catch (Exception e) {
            e.printStackTrace();
            return CommonResult.error("查询失败");
        }
    }
}
