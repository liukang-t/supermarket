package com.example.demo.utils;

import cn.hutool.crypto.digest.BCrypt;

public class PasswordCryptoTool {

    public static String encryptPassword(String password){

        return BCrypt.hashpw(password, BCrypt.gensalt());
    }

    public static Boolean checkPassword(String password,String encryptPassword){
        return BCrypt.checkpw(password, encryptPassword);
    }
}
