package com.example.demo.utils;

import org.apache.commons.lang3.StringUtils;
import com.example.demo.dto.UserDto;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * 缓存操作工具
 */
public class SessionUtil {

    /**
     * 从请求中获取token
     *
     * @param request 请求
     * @return token
     */
    public static String getTokenFromRequest(HttpServletRequest request){
        String token = request.getParameter("token");
        if (StringUtils.isBlank(token)){
            token = request.getHeader("token");
        }
        return token;
    }
    /**
     *  通过token从session中获取用户信息
     * @param request 请求
     * @return token
     */
    public static UserDto getUserFromSession(HttpServletRequest request){

        String token = getTokenFromRequest(request);
        System.out.println(token);
        //获取缓存
        return (UserDto) request.getSession().getAttribute(token);
    }
}
