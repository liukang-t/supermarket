package com.example.demo.utils;

import cn.hutool.core.net.NetUtil;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class UploadFileUtil {
    private static final String saveUrl = "D:/图片/";
    //保存到本机上的一个文件夹
    private static String host = "";
    //电脑的ip地址
    private static final String returnUrl = "/file/getFile?filePath=";
    //返回给前端 下载文件的接口路径
    static {
        host= NetUtil.getLocalhost().getHostAddress();
    }
//使用hutool工具类获取本机ip地址
    public static String generateName(String fileName){
//        随机生成随机名称
        String uuid = UUID.randomUUID().toString().replace("-", "");
//        判断名称是否有后缀名
        if(fileName.lastIndexOf('.')<0){
            return uuid +".jpg";
        }
        return uuid+fileName.substring(fileName.lastIndexOf("."));
    }

    public static String localSave(MultipartFile file,String port) throws IOException {
//        生成随机的文件名
        String generateName = generateName(file.getOriginalFilename());
//        根据saveUrl创建文件对象，来判断是否存在
        File saveOir = new File(saveUrl);
        if (saveOir.exists()){
            saveOir.mkdirs();
        }
//       创建要保存的文件对象，并保存文件
        File savefile = new File(saveOir, generateName);
        file.transferTo(savefile);
        return "Http://"+host+":"+port+returnUrl+saveUrl+generateName;

    }
    /**
     * 根据下载路径获取文件在磁盘内的路径
     * @param downloadUrl
     * @return
     */
    public static String getFilePath(String downloadUrl) {
        //http://192.168.43.152:8084/file/getFile?filePath=
        // D:/test/image/fd0840586dd74a8496906765c5024f38.jpg
        return downloadUrl.substring(downloadUrl.lastIndexOf("filePath=") + 9);
    }
    public  static  String getDownloadUrl(String filePath ,String Post){
        if (filePath != null && !filePath.contains("http://")){
            return "Http://"+host+":"+Post + returnUrl + filePath;
        }
        return filePath;
    }
    public static Boolean deleteFile(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            return file.delete();
        }
        return false;
    }
}
