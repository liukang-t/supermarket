package com.example.demo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BaseVo {
    public static final Integer NOT_DELETED = 0;
    public static final Integer DELETED = 1;
    /**
     * 页码
     */
    private  Integer pageNum;
    /**
     * 数量
     */
    private  Integer pageSize;
    /**
     * 偏移量
     */
    private  Integer offset;
    /**
     *关键词
     */
    private String key;
    /**
     * id
     */
    private Integer id;

    /**
     * id列表
     */
    private List<Integer> idList;

    private Integer getOffset(){
        if (pageNum !=null && pageNum >0 && pageSize !=null && pageSize >0){
            return (pageNum -1)*pageSize;
        }
        return null;
    }

}
