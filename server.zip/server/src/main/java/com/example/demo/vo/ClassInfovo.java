package com.example.demo.vo;

import lombok.Data;

@Data
public class ClassInfovo extends BaseVo{
        /**
         * 班级名称:
         */
            private String className;
        /**
         * 实训标题:
         */
            private String practiceTitle;
        /**
         * 实训内容:
         */
            private String practiceContent;
        /**
         * 辅导员名称:
         */
           private String prcounselor;
        /**
         * 辅导员电话:
         */
           private String counselorTelephone;
        /**
         * 学校名称:
         */
           private String  schoolName;
        /**
         * 院系名称:
         */
           private String departmentName;
}
