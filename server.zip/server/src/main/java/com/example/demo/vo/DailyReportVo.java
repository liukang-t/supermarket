package com.example.demo.vo;

import lombok.Data;

@Data
public class DailyReportVo extends BaseVo{

    /**
     * 存在的问题
     */
    private String problem;

    /**
     * 日报内容
     */
    private String content;

    /**
     * 关联的学生id
     */
    private Integer relationStudentId;


    /**
     * 班级id
     */
    private Integer relationClassId;


    /**
     * 教师id
     */
    private Integer relationTeacherId;

    /**
     * 日报内容
     */
    private String comment;

}
