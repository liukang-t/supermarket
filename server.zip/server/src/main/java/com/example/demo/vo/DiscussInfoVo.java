package com.example.demo.vo;

import com.example.demo.po.DiscussInfo;
import lombok.Data;

@Data
public class DiscussInfoVo extends BaseVo {

    private String content; //内容

    private String imgUrl;//文件上传路径

    private Integer relationClassId;//关联班级ID

    /**
     * 页码
     */
    private Integer page;

    /**
     * 数量
     */
    private Integer size;
    /**
     * 删除的数据类型： 1-答疑 2-回复
     */
    private Integer type;
    /**
     * 删除数据的id
     */
    private Integer id;

}
