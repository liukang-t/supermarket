package com.example.demo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QueryVo extends BaseVo{
    public Integer leix;
    //    资源图片
    private String pic;
    //    资源名称
    private  String name;

    //    关联购买人数
    private String buy_n;

    //    单价
    private String price;

    //id列表
    private List<Integer> idList;
}
