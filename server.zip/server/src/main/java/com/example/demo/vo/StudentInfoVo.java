package com.example.demo.vo;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

@Data
public class StudentInfoVo extends BaseVo{
/*    name: '',
    studentNum: '',
    gender: '',
    classId: '',
    idCardNumber: '',
    telephone: '',
    email: '',
    address: ''*/
    /**
     * 学生姓名
     */
    private String studentName;

    /**
     * 学号
     */
    private String studentNumber;

    /**
     * 性别 1男 2女
     */
    private Integer gender;

    /**
     * 班级id
     */
    private Integer relationClassId;

    /**
     * 年龄
     */
    private Integer age;

    /**
     * 生日
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birth;

    /**
     * 关联的relationTeacherId教师id
     */
    private Integer relationTeacherId;

    /**
     *
     */
    private List<Integer> idList;
}
