package com.example.demo.vo;

import lombok.Data;

@Data
public class TaskGradeVo extends BaseVo{

    private Integer taskId;
//    任务id

    private Integer relationClassId;
//    数量

    private Integer studentId;
//    学生id

    private String Score;
//    分数

}
