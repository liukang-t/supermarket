package com.example.demo.vo;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class TaskInfoVo extends BaseVo{

    private String  taskName;
//    任务名称

    private String  content;
//    任务内容

    private Date startTime;
//    开始时间

    private Date endTime;
//    结束时间

    private Integer relationClassId;
//    关联班级id

    private Integer id;
//id

    private List<Integer> idList;
//任务id列表

}
