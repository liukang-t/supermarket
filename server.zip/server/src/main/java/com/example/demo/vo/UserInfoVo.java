package com.example.demo.vo;

import com.example.demo.dto.UserDto;
import lombok.Data;

@Data
public class UserInfoVo {
    public UserDto userDto;
    /**
     * 用户昵称
     */
    private String teacherName;

    /**
     * 账号
     */
    private String accountNum;

    /**
     * 密码
     */
    private String password;

    /**
     * 旧密码
     */
    private  String oldPassword;


    /**
     * 新密码
     */
    private  String newPassword;


    /**
     * 头像
     */
    private String avatar;


}
