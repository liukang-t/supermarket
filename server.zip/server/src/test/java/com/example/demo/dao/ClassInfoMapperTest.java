package com.example.demo.dao;

import com.example.demo.po.ClassInfo;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

@SpringBootTest
public class ClassInfoMapperTest {

    @Resource
    ClassInfoMapper classInfoMapper ;

    @Test
    public void addClass() {
        ClassInfo classInfo = new ClassInfo();
        classInfo.setRelationTeacherId(1);
        classInfo.setClassName("软件工程3");
        classInfo.setPracticeTitle("软件工程实训3");
        classInfo.setPracticeContent("软件工程实训内容");
        classInfo.setCounselor("张三");
        classInfo.setCounselorTelephone("123456789");
        int insert = classInfoMapper.insert(classInfo);
        System.out.println(insert);
    }
}
